# BitGen
> A Bitcoin scrapper


This is a simple Bitcoin wallet scrapper it's checks random wallets that it generates against an API and saves ones that have Bitcoin in them in a file for you to 
use.


## Development setup

```sh
pip install -r requirments.txt
```
```sh
python3.8 main.py
```

## Release History



* 0.0.1
    * initial release

## Meta

Anas Arbaoui – [@Anarbbb](https://twitter.com/Anarbbb) – anarbaoui@gmail.com

Distributed under the GPL-3.0 license. See ``LICENSE`` for more information.

[https://github.com/Anarbb/](https://github.com/Anarbb/)

## Contributing

1. Fork it (<https://github.com/Anarbb/BitGen/fork>)
2. Create your feature branch (`git checkout -b feature/fooBar`)
3. Commit your changes (`git commit -am 'Add some fooBar'`)
4. Push to the branch (`git push origin feature/fooBar`)
5. Create a new Pull Request

## Copyright

Copyright (c) 2020 Anas Arbaoui

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
